#19 Control de Aforo en un Recinto
capacidad_maxima = 5
personas_adentro = 0

while personas_adentro < capacidad_maxima:
    input("Pulse ENTER para permitir la entrada de la siguiente persona ")
    personas_adentro += 1
    print(f"Total de personas registradas: {personas_adentro}/{capacidad_maxima}\n")

print("Aforo completo")