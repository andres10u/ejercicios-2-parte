#22 Temporizador de Timeout de Servidor
import time

print("Iniciando conexión con el servidor...")
for segundo in range(1, 6):
    print(f"Tiempo transcurrido esperando respuesta: {segundo}s")
    time.sleep(1)

print("Tiempo de espera agotado (Timeout)")