#20 Simulador de Intereses por Mora
deuda = float(input("Digite el monto que tiene pendiente por pagar: $"))
meses = int(input("Indique cuántos meses lleva sin pagar: "))

TASA_INTERES = 0.05

for mes in range(1, meses + 1):
    deuda += deuda * TASA_INTERES
    print(f"Mes {mes}: Deuda acumulada = ${deuda}")

print(f"\nValor total pendiente después de la mora: ${deuda}")