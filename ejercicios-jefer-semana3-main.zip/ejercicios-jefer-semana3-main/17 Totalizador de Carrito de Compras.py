#17 Totalizador de Carrito de Compras
total = 0

while True:
    precio = float(input("Digite el costo del artículo que va a registrar (0 para cerrar la caja): $"))
    if precio == 0:
        break
    elif precio < 0:
        print("Error: El precio no puede ser negativo.")
    else:
        total += precio

print(f"\nValor acumulado de la compra: ${total}")