#30 Máximo Común Divisor (MCD) por Algoritmo de Euclides
numa = int(input("Digite el primer valor entero positivo: "))
numb = int(input("Digite el segundo valor entero positivo: "))

num1, num2 = numa, numb

while numb != 0:
    residuo = numa % numb
    numa = numb
    numb = residuo

print(f"El MCD de los valores {num1} y {num2} corresponde a: {numa}")