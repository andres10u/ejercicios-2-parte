#23 Juego "Adivina el Número Secreto"
import random

numero_secreto = random.randint(1, 10)
intentos = 0

print("¡Comienza el reto! Descubre el número oculto entre 1 y 10.")

while True:
    intento = int(input("Escribe el número que crees que es: "))
    intentos += 1

    if intento < numero_secreto:
        print("Prueba con un número más alto.\n")
    elif intento > numero_secreto:
        print("Prueba con un número más bajo.\n")
    else:
        print(f"¡Felicidades! Adivinaste el número {numero_secreto} en {intentos} intento(s).")
        break