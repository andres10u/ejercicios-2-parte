#21 Registro de Asistencia
presentes = 0
ausentes = 0

while True:
    estado = input("Registre el estado del aprendiz ('P': Presente, 'A': Ausente, 'F': Terminar): ").strip().upper()

    if estado == 'F':
        break
    elif estado == 'P':
        presentes += 1
    elif estado == 'A':
        ausentes += 1
    else:
        print("Opción no válida. Ingrese P, A o F.")

print("\nRESUMEN DE ASISTENCIA")
print(f"Total de aprendices que asistieron: {presentes}")
print(f"Total de aprendices que faltaron: {ausentes}")