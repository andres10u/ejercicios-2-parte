#26 Buscador de Valor Máximo
maximo = None

print("Digite varios números enteros (escriba 0 para finalizar el registro):")
while True:
    numero = int(input("Ingrese un valor: "))

    if numero == 0:
        break

    if maximo is None or numero > maximo:
        maximo = numero

if maximo is not None:
    print(f"\nEl valor más grande de los números registrados es: {maximo}")
else:
    print("\nNo se registraron números antes de finalizar.")