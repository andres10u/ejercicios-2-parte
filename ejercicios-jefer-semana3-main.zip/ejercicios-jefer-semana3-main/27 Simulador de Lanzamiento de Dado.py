#27 Simulador de Lanzamiento de Dado
import random

lanzamiento = 0
contador = 0

while lanzamiento != 6:
    lanzamiento = random.randint(1, 6)
    contador += 1
    print(f"Tirada número {contador}: El dado cayó en {lanzamiento}")

print(f"\n¡El dado mostró un 6 después de {contador} tirada(s)!")