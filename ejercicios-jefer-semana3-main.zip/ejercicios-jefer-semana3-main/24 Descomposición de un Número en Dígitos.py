#24 Descomposición de un Número en Dígitos
numero = int(input("Digite el número que desea separar en cifras: "))

if numero <= 0:
    print("Por favor, ingrese un número entero positivo.")
else:
    temp = numero
    print(f"Cifras individuales de {numero}, empezando por la derecha:")
    while temp > 0:
        digito = temp % 10
        print(digito)
        temp //= 10