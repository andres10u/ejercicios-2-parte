#18 Cajero Automático - Retiro de Dinero
saldo = 500000

while saldo > 0:
    print(f"Dinero disponible en la cuenta: ${saldo}")
    retiro = float(input("Digite cuánto dinero desea retirar (0 para cancelar): $"))

    if retiro == 0:
        print("Transacción finalizada por el usuario.")
        break
    elif retiro < 0:
        print("Error: El monto no puede ser negativo.\n")
    elif retiro > saldo:
        print("Error: Fondos insuficientes.\n")
    else:
        saldo -= retiro
        print(f"Retiro exitoso. Dinero entregado: ${retiro}\n")

print(f"Operación terminada. Dinero disponible en la cuenta: ${saldo}")