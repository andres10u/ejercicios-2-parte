#29 Suma de los Dígitos de un Número
numero = int(input("Digite el número del que desea sumar sus cifras: "))
temp = abs(numero)
suma = 0

while temp > 0:
    suma += temp % 10
    temp //= 10

print(f"El resultado de sumar las cifras de {numero} es: {suma}")